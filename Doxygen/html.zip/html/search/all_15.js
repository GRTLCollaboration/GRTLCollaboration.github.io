var searchData=
[
  ['widthsf',['widthSF',['../class_simulation_parameters.html#a5188f8ef04c503a72469c90ea454c9e9',1,'SimulationParameters::widthSF()'],['../struct_scalar_bubble_1_1params__t.html#a00e398d9691564090530b5f234a633be',1,'ScalarBubble::params_t::widthSF()']]]
];
