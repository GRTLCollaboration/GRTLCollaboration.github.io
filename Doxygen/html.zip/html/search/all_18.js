var searchData=
[
  ['z',['z',['../class_coordinates.html#a0060e190cc1d519f4f57ee796de031a2',1,'Coordinates']]],
  ['z_5fover_5fchi',['Z_over_chi',['../values1_8hpp.html#a40364da5a2613855c201d51566e283bb',1,'values1.hpp']]]
];
